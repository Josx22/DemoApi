using DemoApi.Data; // Aseg�rate de que este namespace coincida con tu carpeta Data
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// 1. CONFIGURACI�N DE SERVICIOS
builder.Services.AddRazorPages();

// AGREGA ESTO: Permite usar los controladores (ProductsController)
builder.Services.AddControllers();

// AGREGA ESTO: Configura la conexi�n a tu Base de Datos (SQL Server)
builder.Services.AddDbContext<DemoApiDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// AGREGA ESTO: Configuraci�n necesaria para Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// 2. CONFIGURACI�N DEL PIPELINE (Middleware)

// AGREGA ESTO: Habilita Swagger solo en desarrollo
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

// MAPEO DE RUTAS
app.MapRazorPages();

// AGREGA ESTO: Es vital para que tus rutas de API (/api/products) funcionen
app.MapControllers();

app.Run();