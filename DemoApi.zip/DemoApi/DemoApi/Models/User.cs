﻿using System.ComponentModel.DataAnnotations;

namespace DemoApi.Models
{
    public class User
    {
        [Key]
        public int IdUsuario { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Apellido { get; set; } = string.Empty;
        public string imagenperfil { get; set; }
    }
}
