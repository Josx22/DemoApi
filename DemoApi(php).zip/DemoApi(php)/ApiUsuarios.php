<?php

$apiUrl = 'http://localhost:5298/api/users';
$response = file_get_contents($apiUrl);

$users = json_decode($response, true);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Consumo de Api.Net en PHP</title>
</head>
  <style>
        /* Agregamos un poco de estilo para que las imágenes no sean gigantes */
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
        .producto-img {
            width: 100px; /* Ancho de la miniatura */
            height: auto;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
    </style>
<body>
    <h1>LISTA DE USUARIOS</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Imagen</th>
        </tr>
        <?php if (!empty($users)): ?>
            <?php foreach ($users as $p): ?>
                <tr onclick="alert('Seleccionaste: <?= htmlspecialchars($p['nombre']); ?>')">
                    <td><?= htmlspecialchars($p['idUsuario']); ?></td>
                    <td><?= htmlspecialchars($p['nombre']); ?></td>
                    <td><?= htmlspecialchars($p['apellido']); ?></td>
                    <td>
                        <?php if (!empty($p['imagenperfil'])): ?>
                            <img src="<?= htmlspecialchars($p['imagenperfil']); ?>" 
                                 alt="<?= htmlspecialchars($p['nombre']); ?>" 
                                 class="producto-img">
                        <?php else: ?>
                            <span>Sin imagen</span>
                        <?php endif; ?>
                    </td>
                </tr>

                
            <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3">No hay productos disponibles.</td>
                </tr>
        <?php endif; ?>
    </table>
    <div class=footer>
        Demo intrusivo con PHP + API.NET
    </div>
</body>
</html>