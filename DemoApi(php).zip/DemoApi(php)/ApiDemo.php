<?php

$apiUrl = 'http://localhost:5298/api/products';
$response = file_get_contents($apiUrl);

$products = json_decode($response, true);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Consumo de Api.Net en PHP</title>
</head>
  <style>
        /* Agregamos un poco de estilo para que las imágenes no sean gigantes */
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
        .producto-img {
            width: 100px; /* Ancho de la miniatura */
            height: auto;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
    </style>
<body>
    <h1>LISTA DE PRODUCTOS</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Imagen</th>
        </tr>
        <?php if (!empty($products)): ?>
            <?php foreach ($products as $p): ?>
                <tr onclick="alert('Seleccionaste: <?= htmlspecialchars($p['name']); ?>')">
                    <td><?= htmlspecialchars($p['id']); ?></td>
                    <td><?= htmlspecialchars($p['name']); ?></td>
                    <td><?= htmlspecialchars($p['price']); ?></td>
                    <td>
                        <?php if (!empty($p['img'])): ?>
                            <img src="<?= htmlspecialchars($p['img']); ?>" 
                                 alt="<?= htmlspecialchars($p['name']); ?>" 
                                 class="producto-img">
                        <?php else: ?>
                            <span>Sin imagen</span>
                        <?php endif; ?>
                    </td>
                </tr>

                
            <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3">No hay productos disponibles.</td>
                </tr>
        <?php endif; ?>
    </table>
    <div class=footer>
        Demo intrusivo con PHP + API.NET
    </div>
</body>
</html>